//
//  main.m
//  OpenTheDoor
//
//  Created by hetao on 2018/5/18.
//  Copyright © 2018年 hetao. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
