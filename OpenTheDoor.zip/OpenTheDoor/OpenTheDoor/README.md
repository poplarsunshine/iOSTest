### URL
https://mobile.api.doordu.com/api/index.php/v10/doors/open

###  Header
Host: mobile.api.doordu.com
Content-Type: application/x-www-form-urlencoded
Accept: */*
doordu-system: {"app_version":"1.3.8","system_type":"1","system_version":"11.3","system_models":"iPhone6sPlus"}
Accept-Encoding: br, gzip, deflate
Connection: keep-alive
Content-Length: 177
User-Agent: BSH/1.3.8 (iPhone; iOS 11.3; Scale/3.00)
Accept-Language: zh-Hans-CN;q=1, en-CN;q=0.9
Authorization: Basic YTQ3YTc4OTg0ODFlYWJmNzdhMWE1Y2UwNjFmNzkwOGI6OTNmMzgyZmZmY2EyN2Y4ZTRjODBlOGQ3NWUzNzM5MGU=
Package-Name: com.doordu.doordushijie

###  body
device_guid=10C608A0-3168-4BDA-A3F7-6BA2D18F2738&device_type=3&door_guid=BDD4001702-4854&door_id=619590&room_id=4958767&token=68028be2-1a8a-441a-ab17-bd549ae31f68&user_id=713958

###  doorID
1-1后门door_guid=BDD4001702-4854&door_id=619590
1-1前门door_guid=BDD4001702-5620&door_id=643804
东门door_guid=BDD4001702-4888&door_id=618448
